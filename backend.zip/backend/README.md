## How to run?

* python run.py - runs application on the 5000 port.
* python test_api.py - runs tests.
* 127.0.0.1:5000/docs - SWAGGER documentation for API.