from .test_auth_api import TestAuthAPI
from .test_employees_api import TestEmployeesAPI
from .test_clients_api import TestClientsAPI
from .test_equipments_api import TestEquipmentsAPI
from .test_rentals_api import TestRentalsAPI
