from .rental_repository import RentalRepository
from .rentals_repository import RentalsRepository
