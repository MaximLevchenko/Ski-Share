from .auth import auth_namespace
from .clients import clients_namespace
from .employees import employees_namespace
from .equipments import equipments_namespace
from .rentals import rentals_namespace
