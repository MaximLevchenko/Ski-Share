from .rentals_route import rentals_namespace
